# Deployment Guide

This guide covers deploying CapMeToo to various platforms.

## 🚀 GitHub Pages (Recommended)

Perfect for free hosting with automatic deployments.

### Prerequisites
- GitHub account
- Repository with CapMeToo code

### Setup Steps

1. **Enable GitHub Pages**
   \`\`\`bash
   # In your repository settings
   Settings → Pages → Source: GitHub Actions
   \`\`\`

2. **Create Workflow File**
   \`\`\`yaml
   # .github/workflows/deploy.yml
   name: Deploy to GitHub Pages
   
   on:
     push:
       branches: [ main ]
     pull_request:
       branches: [ main ]
   
   jobs:
     build-and-deploy:
       runs-on: ubuntu-latest
       steps:
         - uses: actions/checkout@v3
         
         - name: Setup Node.js
           uses: actions/setup-node@v3
           with:
             node-version: '18'
             cache: 'npm'
         
         - name: Install dependencies
           run: npm ci
         
         - name: Build
           run: npm run build
         
         - name: Deploy
           uses: peaceiris/actions-gh-pages@v3
           with:
             github_token: ${{ secrets.GITHUB_TOKEN }}
             publish_dir: ./out
   \`\`\`

3. **Configure Next.js**
   \`\`\`javascript
   // next.config.js
   /** @type {import('next').NextConfig} */
   const nextConfig = {
     output: 'export',
     trailingSlash: true,
     images: {
       unoptimized: true
     },
     basePath: process.env.NODE_ENV === 'production' ? '/capmetoo' : '',
     assetPrefix: process.env.NODE_ENV === 'production' ? '/capmetoo/' : '',
   }
   
   module.exports = nextConfig
   \`\`\`

### Custom Domain (Optional)
1. Add `CNAME` file to `public/` directory
2. Configure DNS settings
3. Enable HTTPS in repository settings

## ⚡ Vercel

Optimal for Next.js applications with zero configuration.

### Deployment Steps

1. **Connect Repository**
   - Visit [Vercel](https://vercel.com)
   - Import your GitHub repository
   - Configure project settings

2. **Environment Variables**
   \`\`\`bash
   # Add in Vercel dashboard
   NEXT_PUBLIC_GEMINI_API_KEY=your_key_here  # Optional
   \`\`\`

3. **Deploy**
   - Automatic deployment on every push
   - Preview deployments for pull requests
   - Custom domains supported

### Vercel Configuration
\`\`\`json
{
  "buildCommand": "npm run build",
  "outputDirectory": ".next",
  "installCommand": "npm install",
  "framework": "nextjs"
}
\`\`\`

## 🌐 Netlify

Great alternative with form handling and edge functions.

### Deployment Options

**Option 1: Git Integration**
1. Connect your repository
2. Set build command: `npm run build`
3. Set publish directory: `out`
4. Deploy automatically

**Option 2: Manual Upload**
\`\`\`bash
# Build locally
npm run build

# Upload 'out' directory to Netlify
\`\`\`

### Netlify Configuration
\`\`\`toml
# netlify.toml
[build]
  command = "npm run build"
  publish = "out"

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-XSS-Protection = "1; mode=block"
    X-Content-Type-Options = "nosniff"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
\`\`\`

## 🐳 Docker

For containerized deployments.

### Dockerfile
\`\`\`dockerfile
FROM node:18-alpine AS base

# Install dependencies
FROM base AS deps
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci

# Build application
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

# Production image
FROM base AS runner
WORKDIR /app

ENV NODE_ENV production

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs

EXPOSE 3000

ENV PORT 3000

CMD ["node", "server.js"]
\`\`\`

### Docker Compose
\`\`\`yaml
version: '3.8'
services:
  capmetoo:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
    restart: unless-stopped
\`\`\`

## ☁️ Cloud Platforms

### AWS S3 + CloudFront
\`\`\`bash
# Build for static hosting
npm run build

# Upload to S3
aws s3 sync out/ s3://your-bucket-name --delete

# Invalidate CloudFront
aws cloudfront create-invalidation --distribution-id YOUR_ID --paths "/*"
\`\`\`

### Google Cloud Storage
\`\`\`bash
# Build application
npm run build

# Upload to GCS
gsutil -m rsync -r -d out/ gs://your-bucket-name

# Set public access
gsutil -m acl ch -r -u AllUsers:R gs://your-bucket-name
\`\`\`

## 🔧 Environment Configuration

### Production Environment Variables
\`\`\`bash
# Required for AI functionality
NEXT_PUBLIC_GEMINI_API_KEY=your_production_key

# Optional analytics
NEXT_PUBLIC_GA_ID=your_google_analytics_id
NEXT_PUBLIC_HOTJAR_ID=your_hotjar_id

# Security headers
NEXT_PUBLIC_CSP_NONCE=random_nonce_value
\`\`\`

### Build Optimization
\`\`\`javascript
// next.config.js
const nextConfig = {
  // Enable compression
  compress: true,
  
  // Optimize images
  images: {
    formats: ['image/webp', 'image/avif'],
    minimumCacheTTL: 60,
  },
  
  // Enable SWC minification
  swcMinify: true,
  
  // Experimental features
  experimental: {
    optimizeCss: true,
    optimizePackageImports: ['lucide-react'],
  },
}
\`\`\`

## 📊 Performance Monitoring

### Core Web Vitals
- Monitor LCP, FID, and CLS
- Use Lighthouse for audits
- Implement performance budgets

### Analytics Setup
\`\`\`typescript
// utils/analytics.ts
export const trackEvent = (action: string, category: string) => {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', action, {
      event_category: category,
      event_label: window.location.pathname,
    })
  }
}
\`\`\`

## 🔒 Security Considerations

### Content Security Policy
\`\`\`javascript
// next.config.js
const securityHeaders = [
  {
    key: 'Content-Security-Policy',
    value: `
      default-src 'self';
      script-src 'self' 'unsafe-eval' 'unsafe-inline';
      style-src 'self' 'unsafe-inline';
      img-src 'self' data: blob:;
      connect-src 'self' https://generativelanguage.googleapis.com;
    `.replace(/\s{2,}/g, ' ').trim()
  }
]
\`\`\`

### HTTPS Configuration
- Always use HTTPS in production
- Configure HSTS headers
- Use secure cookies

## 🚨 Troubleshooting

### Common Issues

**Build Failures**
\`\`\`bash
# Clear cache and reinstall
rm -rf .next node_modules package-lock.json
npm install
npm run build
\`\`\`

**Static Export Issues**
\`\`\`javascript
// Ensure all pages are statically exportable
// Avoid server-side only features
// Use next/image with unoptimized: true
\`\`\`

**API Key Issues**
- Verify environment variables
- Check API key permissions
- Monitor usage quotas

### Deployment Checklist
- [ ] Build completes successfully
- [ ] All environment variables set
- [ ] HTTPS enabled
- [ ] Custom domain configured
- [ ] Performance optimized
- [ ] Security headers configured
- [ ] Analytics tracking works
- [ ] PWA features functional

---

**Need help with deployment?** [Open an issue](https://github.com/your-username/capmetoo/issues) or check our [FAQ](faq.md).
